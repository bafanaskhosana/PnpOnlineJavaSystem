var pnpModule = angular.module("myapp",[]);
function lettersOnly(input){
        var regex = /[^a-z]/gi;
        input.value=input.value.replace(regex,"");
    }
pnpModule.controller("productController", function($scope,$http)
    
{  $http.defaults.headers.post["Content-Type"] = "application/json";
    //console.log("inside controller");
    $http.get('http://localhost:8181/GetProducts').then(function(response){
        console.log(response.data);
        $scope.products = response.data;
        console.log($scope.products);
    });
    
    

    $http.get('http://localhost:8181/GetDelivery').then(function(response){
        console.log(response.data);
        $scope.delivery = response.data;
        console.log($scope.delivery);
    });
    $http.get('http://localhost:8181/GetSupplier').then(function(response){
        console.log(response.data);
        $scope.supplier = response.data;
        console.log($scope.supplier);
    });
    $http.get('http://localhost:8181/GetCustomers').then(function(response){
        console.log(response.data);
        $scope.user = response.data;
        console.log($scope.user);
    });
    
    $http.get('http://localhost:8181/GetCarts').then(function(response){
        console.log(response.data);
        $scope.cart = response.data;
        console.log($scope.cart);
    });
    /////// Add to cart database
   $scope.save = function ()
   {
        var Add2Cart = {
	            "pname": productController.pname,
                    "pprice":productController.pprice,
                    "product_image" :  productController.pimage 
        }
   };
            $scope.processProduct = function() {
		console.log($scope.productController);
                    var file = document.getElementById('pimage');
                   
                    var name = "/images/" + file.files.item(0).name;
                    $scope.productController.pimage = name;
                    
                $http({
				method : 'POST',
				url : 'http://localhost:8181/InsertProducts',
				data : angular.toJson($scope.productController),
				headers : {
					'Content-Type' : 'application/json'
				}     
			})
			  .success(function(data){

				$scope.productController= data;
                        alert("Product Saved");
                        location.reload(true);
		    });	
		};
                
                
                
            $scope.processSupplier = function() {
		console.log($scope.productController);
            
                $http({
				method : 'POST',
				url : 'http://localhost:8181/InsertNewProducts',
				data : angular.toJson($scope.productController),
				headers : {
					'Content-Type' : 'application/json'
				}
                               
			})
			  .success(function(data){
                              
				$scope.productController= data;
                        alert("Product Requested");
                        location.reload(true);
		    });
			
		};
                
                
             
                $scope.processDelivery = function( suburb, contact, datepicker, dtime, slocation, location, city ) {
		console.log(user);
                    //var file = document.getElementById('pimage');
                    //var name = "/images/" + file.files.item(0).name;
                    //$scope.productController.pimage = name;
                    
                             
                if(user === undefined)
                {   
                    
                    document.getElementById('user').style.borderColor ="red";
                }
                else
                {
                    if(suburb === undefined)
                    {
                        alert("Please enter the surburb.");
                        document.getElementById('suburb').style.borderColor ="red";
                    }
                    else
                    {
                        if(contact === undefined)
                        {
                            alert("Please enter the contact.");
                            document.getElementById('contact').style.borderColor ="red";
                           
                        }
                        else
                        {
                            if(datepicker === undefined || dtime === undefined )
                            {
                                alert("Please enter the date of delivery.");
                                document.getElementById('datepicker').style.borderColor ="red";
                              
                            }
                            else
                            {
                                if(slocation === undefined)
                                {
                                    alert("Please enter the street location of delivery.");
                                    document.getElementById('slocation').style.borderColor ="red";
                                }
                                else
                                {
                                    if(location === undefined)
                                    {
                                        alert("Please enter the location of delivery.");
                                        document.getElementById('contact').style.borderColor ="red";
                                    }
                                    else
                                    {
                                        if(city === undefined)
                                        {
                                            alert("Please enter the city of delivery.");
                                            document.getElementById('city').style.borderColor ="red";
                                        }
                                        else
                                        {
                                            var addDelivery = {
                                                
                                                contact: contact,
                                                datepicker : datepicker,
                                                suburb : suburb,
                                                dtime : dtime,
                                                slocation : slocation,
                                                location: location,
                                                city : city
                                            }
                                            
                                            $http({
                                                        method : 'POST',
                                                        url : 'http://localhost:8181/InsertDelivery',
                                                        data : angular.toJson(addDelivery),
                                                        headers : {
                                                                'Content-Type' : 'application/json'
                                                        }
                                                })
                                                .success(function(data){
                                                $scope.productController= data;
                                                alert("Delivery Captured");
                                                location.reload(true);
                                            });
                                       
                                        }
                                    }
                                }
                            }
                        }

                    }
                    
                }
                
			
		};
                
           
                $scope.processPayment = function(username, cardno, accno, bank, cardtype) {
		console.log($scope.productController);
                    //var file = document.getElementById('pimage');
                    //var name = "/images/" + file.files.item(0).name;
                    //$scope.productController.pimage = name;
                          
                if(username === undefined)
                {   
                    alert("Please enter the username.");
                    document.getElementById('username').style.borderColor ="red";
                }
                else
                {
                    if(cardno === undefined)
                {   
                    alert("Please enter the cardno.");
                    document.getElementById('cardno').style.borderColor ="red";
                }
                else
                {
                    if(accno === undefined)
                {   
                    alert("Please enter the accno.");
                    document.getElementById('accno').style.borderColor ="red";
                }
                else
                {
                    if(bank === undefined)
                {   
                    alert("Please select bank.");
                    document.getElementById('bank').style.borderColor ="red";
                }
                else
                {
                    if(cardtype === undefined)
                {   
                    alert("Please select cardtype.");
                    document.getElementById('cardtype').style.borderColor ="red";
                }
                else
                {
                    var addPayment = {
                       username : username,
                       cardno: cardno,
                       accno : accno,
                       bank : bank,
                       cardtype : cardtype,
                       
                       
                                            }
                $http({
				method : 'POST',
				url : 'http://localhost:8181/InsertPayment',
				data : angular.toJson(addPayment),
				headers : {
					'Content-Type' : 'application/json'
				}
			})
			  .success(function(data){
                          $scope.productController= data;
                            alert("Payment done!");
                            location.reload(true);
		    });
                }
                }
                }
            }
        }
                
                
			
		};
  
    });  