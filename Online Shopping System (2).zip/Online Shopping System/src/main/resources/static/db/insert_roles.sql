

INSERT INTO `role` VALUES (1,'ADMIN'); 

insert into `user` (active, email, last_name, name, password) values (?, ?, ?, ?, ?)