package com.pnponline.service;

import com.pnponline.model.Cart;
import com.pnponline.repository.CartRepositry;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service 
public class CartService{

@Autowired
public CartRepositry cartRepository;


    public List<Cart> getAllcarts() //java generic arrayList
    {
        List<Cart> cart = (List<Cart>) cartRepository.findAll();
        return cart;

    }

   
    

    
}