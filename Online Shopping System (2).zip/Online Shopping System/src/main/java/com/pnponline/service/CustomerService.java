package com.pnponline.service;

import com.pnponline.model.User;
import com.pnponline.repository.CustomerRepositry;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service 
public class CustomerService{

@Autowired
public CustomerRepositry customerRepository;

    public List<User> getAllcustomers()
    {
        List<User> user = (List<User>) customerRepository.findAll();
        return user;

    }

    

    
}