package com.pnponline.service;


import com.pnponline.model.Supplier;
import com.pnponline.repository.SupplierRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service 
public class SupplierService{

@Autowired
public SupplierRepository supplierRepository;

public List<Supplier> getAllsupplier()
    {
        List<Supplier> supplier = (List<Supplier>) supplierRepository.findAll();
        return supplier;

    }

    
    public void AddProducts(Supplier supplier){
      supplierRepository.save(supplier);
    }

    public void save(Supplier supplier) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        supplierRepository.save(supplier);
    }
}