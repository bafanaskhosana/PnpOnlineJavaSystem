package com.pnponline.service;


import com.pnponline.model.Products;
import com.pnponline.repository.ProductRepositry;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service 
public class ProductService{

@Autowired
public ProductRepositry productRepository;

    public List<Products> getAllproducts()
    {
        List<Products> products = (List<Products>) productRepository.findAll();
        return products;

    }
    public void AddProducts(Products products){
      productRepository.save(products);
    }

    public void save(Products products) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        productRepository.save(products);
    }
}