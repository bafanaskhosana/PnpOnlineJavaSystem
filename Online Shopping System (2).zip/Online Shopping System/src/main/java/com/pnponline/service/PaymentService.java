package com.pnponline.service;

import com.pnponline.model.Payments;
import com.pnponline.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service 
public class PaymentService{

@Autowired
public PaymentRepository paymentRepository;

    
    public void AddProducts(Payments payments){
      paymentRepository.save(payments);
    }

    public void save(Payments payments) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        paymentRepository.save(payments);
    }
}