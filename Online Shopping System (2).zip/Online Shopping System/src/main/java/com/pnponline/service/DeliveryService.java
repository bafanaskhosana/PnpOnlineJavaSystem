package com.pnponline.service;


import com.pnponline.model.Delivery;
import com.pnponline.model.Products;
import com.pnponline.repository.DeliveryRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service 
public class DeliveryService{

@Autowired
public DeliveryRepository deliveryRepository;

public List<Delivery> getAllproducts()
    {
        List<Delivery> delivery = (List<Delivery>) deliveryRepository.findAll();
        return delivery;

    }

    
    public void AddProducts(Delivery delivery){
      deliveryRepository.save(delivery);
    }

    public void save(Delivery delivery) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        deliveryRepository.save(delivery);
    }
}