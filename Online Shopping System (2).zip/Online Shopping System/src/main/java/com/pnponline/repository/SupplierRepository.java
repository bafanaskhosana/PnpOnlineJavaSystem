/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pnponline.repository;

import com.pnponline.model.Supplier;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @Bafana Skhosana
 */
public interface SupplierRepository extends CrudRepository <Supplier, Integer>{
    
}
