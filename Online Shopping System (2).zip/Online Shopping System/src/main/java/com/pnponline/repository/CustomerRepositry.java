/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pnponline.repository;



/**
 *
 * @author User
 */
import com.pnponline.model.Products;
import com.pnponline.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface CustomerRepositry extends CrudRepository <User, Integer>  {

    //public Object findAll();
  
    
}