/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pnponline.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.validator.constraints.Email;

/**
 *
 * @author User
 */
@Entity
@Table(name = "payments")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Payments.findAll", query = "SELECT p FROM Payments p")
    , @NamedQuery(name = "Payments.findByPid", query = "SELECT p FROM Payments p WHERE p.pid = :pid")
    , @NamedQuery(name = "Payments.findByBank", query = "SELECT p FROM Payments p WHERE p.bank = :bank")
    , @NamedQuery(name = "Payments.findByCardno", query = "SELECT p FROM Payments p WHERE p.cardno = :cardno")
    , @NamedQuery(name = "Payments.findByCardtype", query = "SELECT p FROM Payments p WHERE p.cardtype = :cardtype")
    , @NamedQuery(name = "Payments.findByExpdate", query = "SELECT p FROM Payments p WHERE p.expdate = :expdate")
    , @NamedQuery(name = "Payments.findByUsername", query = "SELECT p FROM Payments p WHERE p.username = :username")
    , @NamedQuery(name = "Payments.findByAccno", query = "SELECT p FROM Payments p WHERE p.accno = :accno")})
public class Payments implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "pid")
    private Integer pid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "bank")
    private String bank;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "cardno")
    private String cardno;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "cardtype")
    private String cardtype;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "expdate")
    private String expdate;
    @Basic(optional = false)
    @NotNull
    @Email(message = "*Please provide a valid Email")
    @Size(min = 1, max = 255)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "accno")
    private String accno;

    public Payments() {
    }

    public Payments(Integer pid) {
        this.pid = pid;
    }

    public Payments(Integer pid, String bank, String cardno, String cardtype, String expdate, String username, String accno) {
        this.pid = pid;
        this.bank = bank;
        this.cardno = cardno;
        this.cardtype = cardtype;
        this.expdate = expdate;
        this.username = username;
        this.accno = accno;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getCardno() {
        return cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype;
    }

    public String getExpdate() {
        return expdate;
    }

    public void setExpdate(String expdate) {
        this.expdate = expdate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAccno() {
        return accno;
    }

    public void setAccno(String accno) {
        this.accno = accno;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pid != null ? pid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Payments)) {
            return false;
        }
        Payments other = (Payments) object;
        if ((this.pid == null && other.pid != null) || (this.pid != null && !this.pid.equals(other.pid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.pnponline.model.Payments[ pid=" + pid + " ]";
    }
    
}
