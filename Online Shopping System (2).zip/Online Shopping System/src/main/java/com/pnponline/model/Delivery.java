/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pnponline.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.validator.constraints.Email;

/**
 *
 * @author User
 */
@Entity
@Table(name = "delivery")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Delivery.findAll", query = "SELECT d FROM Delivery d")
    , @NamedQuery(name = "Delivery.findByPaymentid", query = "SELECT d FROM Delivery d WHERE d.paymentid = :paymentid")
    , @NamedQuery(name = "Delivery.findByCity", query = "SELECT d FROM Delivery d WHERE d.city = :city")
    , @NamedQuery(name = "Delivery.findByContact", query = "SELECT d FROM Delivery d WHERE d.contact = :contact")
    , @NamedQuery(name = "Delivery.findByDatepicker", query = "SELECT d FROM Delivery d WHERE d.datepicker = :datepicker")
    , @NamedQuery(name = "Delivery.findByDtime", query = "SELECT d FROM Delivery d WHERE d.dtime = :dtime")
    , @NamedQuery(name = "Delivery.findByLocation", query = "SELECT d FROM Delivery d WHERE d.location = :location")
    , @NamedQuery(name = "Delivery.findBySlocation", query = "SELECT d FROM Delivery d WHERE d.slocation = :slocation")
    , @NamedQuery(name = "Delivery.findBySuburb", query = "SELECT d FROM Delivery d WHERE d.suburb = :suburb")
    , @NamedQuery(name = "Delivery.findByUsername", query = "SELECT d FROM Delivery d WHERE d.username = :username")})
public class Delivery implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "paymentid")
    private Integer paymentid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "city")
    private String city;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "contact")
    private String contact;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "datepicker")
    private String datepicker;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "dtime")
    private String dtime;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "location")
    private String location;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "slocation")
    private String slocation;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "suburb")
    private String suburb;
    @Basic(optional = false)
    @NotNull
    @Email(message = "*Please provide a valid Email")
    @Size(min = 1, max = 255)
    @Column(name = "username")
    private String username;

    public Delivery() {
    }

    public Delivery(Integer paymentid) {
        this.paymentid = paymentid;
    }

    public Delivery(Integer paymentid, String city, String contact, String datepicker, String dtime, String location, String slocation, String suburb, String username) {
        this.paymentid = paymentid;
        this.city = city;
        this.contact = contact;
        this.datepicker = datepicker;
        this.dtime = dtime;
        this.location = location;
        this.slocation = slocation;
        this.suburb = suburb;
        this.username = username;
    }

    public Integer getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(Integer paymentid) {
        this.paymentid = paymentid;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDatepicker() {
        return datepicker;
    }

    public void setDatepicker(String datepicker) {
        this.datepicker = datepicker;
    }

    public String getDtime() {
        return dtime;
    }

    public void setDtime(String dtime) {
        this.dtime = dtime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSlocation() {
        return slocation;
    }

    public void setSlocation(String slocation) {
        this.slocation = slocation;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (paymentid != null ? paymentid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Delivery)) {
            return false;
        }
        Delivery other = (Delivery) object;
        if ((this.paymentid == null && other.paymentid != null) || (this.paymentid != null && !this.paymentid.equals(other.paymentid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.pnponline.model.Delivery[ paymentid=" + paymentid + " ]";
    }
    
}
