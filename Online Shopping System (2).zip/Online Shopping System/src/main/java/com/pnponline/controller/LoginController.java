package com.pnponline.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pnponline.model.User;
import com.pnponline.service.UserService;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class LoginController {
	
	@Autowired
	private UserService userService;

	@RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
	public ModelAndView login(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
	
	@RequestMapping(value="/registration", method = RequestMethod.GET)
	public ModelAndView registration(){
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("registration");
		return modelAndView;
	}
        
        @RequestMapping(value="/adminregistration", method = RequestMethod.GET)
	public ModelAndView adminregistration(){
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("adminregistration");
		return modelAndView;
	}
        
        @RequestMapping(value="/driverregistration", method = RequestMethod.GET)
	public ModelAndView driverregistration(){
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("driverregistration");
		return modelAndView;
	}
        @RequestMapping(value="/supplierregistration", method = RequestMethod.GET)
	public ModelAndView supplierregistration(){
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("supplierregistration");
		return modelAndView;
	}
        
        @RequestMapping(value="/payment" , method = RequestMethod.GET)
	public ModelAndView payment(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("payment");
		return modelAndView;
	}
        @RequestMapping(value="/driverview" , method = RequestMethod.GET)
	public ModelAndView driverview(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("driverview");
		return modelAndView;
	}
	
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView createNewUser(@Valid User user, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		User userExists = userService.findUserByEmail(user.getEmail());
		if (userExists != null) {
			bindingResult
					.rejectValue("email", "error.user",
							"There is already a user registered with the email provided");
		}
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("registration");
		} else {
			userService.saveUser(user);
			modelAndView.addObject("successMessage", "User has been registered successfully");
			modelAndView.addObject("user", new User());
			modelAndView.setViewName("registration");
			
		}
		return modelAndView;
	}
        
        @RequestMapping(value = "/adminregistration", method = RequestMethod.POST)
	public ModelAndView createNewAdmin(@Valid User user, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		User userExists = userService.findUserByEmail(user.getEmail());
		if (userExists != null) {
			bindingResult
					.rejectValue("email", "error.user",
							"There is already a user registered with the email provided");
		}
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("adminregistration");
		} else {
			userService.saveAdmin(user);
			modelAndView.addObject("successMessage", "User has been registered successfully");
			modelAndView.addObject("user", new User());
			modelAndView.setViewName("adminregistration");
			
		}
		return modelAndView;
	}
        @RequestMapping(value = "/supplierregistration", method = RequestMethod.POST)
	public ModelAndView createNewSupplier(@Valid User user, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		User userExists = userService.findUserByEmail(user.getEmail());
		if (userExists != null) {
			bindingResult
					.rejectValue("email", "error.user",
							"There is already a user registered with the email provided");
		}
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("supplierregistration");
		} else {
			userService.saveSupplier(user);
			modelAndView.addObject("successMessage", "User has been registered successfully");
			modelAndView.addObject("user", new User());
			modelAndView.setViewName("supplierregistration");
			
		}
		return modelAndView;
	}
        
        @RequestMapping(value = "/driverregistration", method = RequestMethod.POST)
	public ModelAndView createNewDriver(@Valid User user, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		User userExists = userService.findUserByEmail(user.getEmail());
		if (userExists != null) {
			bindingResult
					.rejectValue("email", "error.user",
							"There is already a user registered with the email provided");
		}
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("driverregistration");
		} else {
			userService.saveDriver(user);
			modelAndView.addObject("successMessage", "User has been registered successfully");
			modelAndView.addObject("user", new User());
			modelAndView.setViewName("driverregistration");
			
		}
		return modelAndView;
	}
        
	@RequestMapping(value="/basket", method = RequestMethod.GET)
	public ModelAndView basket(){
		ModelAndView modelAndView = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User user = userService.findUserByEmail(auth.getName());
		modelAndView.addObject("userName", "Welcome " + user.getName() + " " + user.getLastName());
		modelAndView.setViewName("basket");
		return modelAndView;
	}
        
        @RequestMapping(value="/adminpage")
	public ModelAndView adminpage(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("adminpage");
		return modelAndView;
	}
        
        @RequestMapping(value="/guest", method = RequestMethod.GET)
	public ModelAndView guest(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("guest");
		return modelAndView;
	}
        @RequestMapping(value="/supplierview", method = RequestMethod.GET)
	public ModelAndView supplierview(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("supplierview");
		return modelAndView;
	}
        @RequestMapping(value="/default")
	 protected String determineTargetUrl(HttpServletRequest request, HttpServletResponse response) {
	        // Get the role of logged in user
	        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	        String role = auth.getAuthorities().toString();

	        String targetUrl = "";
	        if(role.contains("client")) {
	            targetUrl = "redirect:/basket";
	        } else if(role.contains("admin")) {
	            targetUrl = "redirect:/adminpage";
	        }
	         else if(role.contains("driver")) {
	            targetUrl = "redirect:/driverview";
	        }
	         else if(role.contains("supplier")) {
	            targetUrl = "redirect:/supplierview";
	        }
	        return targetUrl;
	    }
	

}
