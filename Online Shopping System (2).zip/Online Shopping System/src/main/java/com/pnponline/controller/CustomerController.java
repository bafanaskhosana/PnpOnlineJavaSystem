package com.pnponline.controller;


import com.pnponline.model.User;
import com.pnponline.service.CustomerService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
public class CustomerController {
    
    @Autowired
    private CustomerService customerService;
    
    @RequestMapping(value = "/GetCustomers", method = RequestMethod.GET)
    public List<User> getAllcustomers(){
        
        return customerService.getAllcustomers();
        
    }
    
}