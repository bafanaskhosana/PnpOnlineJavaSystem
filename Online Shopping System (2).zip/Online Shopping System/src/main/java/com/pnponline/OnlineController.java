package com.pnponline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class OnlineController {

	public static void main(String[] args) {
		SpringApplication.run(OnlineController.class, args);
	}
}
